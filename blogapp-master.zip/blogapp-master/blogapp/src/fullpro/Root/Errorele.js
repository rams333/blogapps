import './Route.css';
import '../../Styles.css';
function Errorele(){
    return(
        <div className='x'>
            <p>uifskdfsdfsjnfuds</p>
            <p>error has occurred</p>
        </div>
    )
}
export default Errorele;