import '../../Styles.css';
import React from 'react';
import './Route.css';

function Footer() {
    return (
        <footer className='footer'>
            <p> 2024 My Website. All Rights Reserved.</p>
        </footer>
    );
}

export default Footer;
